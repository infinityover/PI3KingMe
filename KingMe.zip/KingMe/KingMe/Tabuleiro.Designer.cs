﻿namespace KingMe
{
    partial class Tabuleiro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Tabuleiro));
            this.pos50 = new System.Windows.Forms.PictureBox();
            this.pos51 = new System.Windows.Forms.PictureBox();
            this.pos52 = new System.Windows.Forms.PictureBox();
            this.pos53 = new System.Windows.Forms.PictureBox();
            this.pos40 = new System.Windows.Forms.PictureBox();
            this.pos41 = new System.Windows.Forms.PictureBox();
            this.pos42 = new System.Windows.Forms.PictureBox();
            this.pos43 = new System.Windows.Forms.PictureBox();
            this.pos30 = new System.Windows.Forms.PictureBox();
            this.pos31 = new System.Windows.Forms.PictureBox();
            this.pos32 = new System.Windows.Forms.PictureBox();
            this.pos33 = new System.Windows.Forms.PictureBox();
            this.pos20 = new System.Windows.Forms.PictureBox();
            this.pos21 = new System.Windows.Forms.PictureBox();
            this.pos22 = new System.Windows.Forms.PictureBox();
            this.pos23 = new System.Windows.Forms.PictureBox();
            this.pos10 = new System.Windows.Forms.PictureBox();
            this.pos11 = new System.Windows.Forms.PictureBox();
            this.pos12 = new System.Windows.Forms.PictureBox();
            this.pos13 = new System.Windows.Forms.PictureBox();
            this.posOperario = new System.Windows.Forms.PictureBox();
            this.posRei = new System.Windows.Forms.PictureBox();
            this.A = new System.Windows.Forms.PictureBox();
            this.B = new System.Windows.Forms.PictureBox();
            this.C = new System.Windows.Forms.PictureBox();
            this.D = new System.Windows.Forms.PictureBox();
            this.E = new System.Windows.Forms.PictureBox();
            this.G = new System.Windows.Forms.PictureBox();
            this.F = new System.Windows.Forms.PictureBox();
            this.H = new System.Windows.Forms.PictureBox();
            this.I = new System.Windows.Forms.PictureBox();
            this.K = new System.Windows.Forms.PictureBox();
            this.J = new System.Windows.Forms.PictureBox();
            this.L = new System.Windows.Forms.PictureBox();
            this.M = new System.Windows.Forms.PictureBox();
            this.mensagem = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbPersonagens = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cmbDestino = new System.Windows.Forms.ComboBox();
            this.btnVerificarVez = new System.Windows.Forms.Button();
            this.btnConfirmarJogada = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pos50)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pos51)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pos52)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pos53)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pos40)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pos41)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pos42)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pos43)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pos30)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pos31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pos32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pos33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pos20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pos21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pos22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pos23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pos10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pos11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pos12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pos13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.posOperario)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.posRei)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.A)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.B)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.D)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.E)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.G)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.F)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.H)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.I)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.K)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.J)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.L)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.M)).BeginInit();
            this.SuspendLayout();
            // 
            // pos50
            // 
            this.pos50.BackColor = System.Drawing.Color.Transparent;
            this.pos50.Location = new System.Drawing.Point(80, 95);
            this.pos50.Name = "pos50";
            this.pos50.Size = new System.Drawing.Size(47, 50);
            this.pos50.TabIndex = 1;
            this.pos50.TabStop = false;
            // 
            // pos51
            // 
            this.pos51.BackColor = System.Drawing.Color.Transparent;
            this.pos51.Location = new System.Drawing.Point(133, 95);
            this.pos51.Name = "pos51";
            this.pos51.Size = new System.Drawing.Size(47, 50);
            this.pos51.TabIndex = 1;
            this.pos51.TabStop = false;
            // 
            // pos52
            // 
            this.pos52.BackColor = System.Drawing.Color.Transparent;
            this.pos52.Location = new System.Drawing.Point(186, 95);
            this.pos52.Name = "pos52";
            this.pos52.Size = new System.Drawing.Size(47, 50);
            this.pos52.TabIndex = 1;
            this.pos52.TabStop = false;
            // 
            // pos53
            // 
            this.pos53.BackColor = System.Drawing.Color.Transparent;
            this.pos53.Location = new System.Drawing.Point(239, 95);
            this.pos53.Name = "pos53";
            this.pos53.Size = new System.Drawing.Size(47, 50);
            this.pos53.TabIndex = 1;
            this.pos53.TabStop = false;
            // 
            // pos40
            // 
            this.pos40.BackColor = System.Drawing.Color.Transparent;
            this.pos40.Location = new System.Drawing.Point(80, 170);
            this.pos40.Name = "pos40";
            this.pos40.Size = new System.Drawing.Size(47, 50);
            this.pos40.TabIndex = 1;
            this.pos40.TabStop = false;
            // 
            // pos41
            // 
            this.pos41.BackColor = System.Drawing.Color.Transparent;
            this.pos41.Location = new System.Drawing.Point(133, 170);
            this.pos41.Name = "pos41";
            this.pos41.Size = new System.Drawing.Size(47, 50);
            this.pos41.TabIndex = 1;
            this.pos41.TabStop = false;
            // 
            // pos42
            // 
            this.pos42.BackColor = System.Drawing.Color.Transparent;
            this.pos42.Location = new System.Drawing.Point(186, 170);
            this.pos42.Name = "pos42";
            this.pos42.Size = new System.Drawing.Size(47, 50);
            this.pos42.TabIndex = 1;
            this.pos42.TabStop = false;
            // 
            // pos43
            // 
            this.pos43.BackColor = System.Drawing.Color.Transparent;
            this.pos43.Location = new System.Drawing.Point(239, 170);
            this.pos43.Name = "pos43";
            this.pos43.Size = new System.Drawing.Size(47, 50);
            this.pos43.TabIndex = 1;
            this.pos43.TabStop = false;
            // 
            // pos30
            // 
            this.pos30.BackColor = System.Drawing.Color.Transparent;
            this.pos30.Location = new System.Drawing.Point(80, 238);
            this.pos30.Name = "pos30";
            this.pos30.Size = new System.Drawing.Size(47, 50);
            this.pos30.TabIndex = 1;
            this.pos30.TabStop = false;
            // 
            // pos31
            // 
            this.pos31.BackColor = System.Drawing.Color.Transparent;
            this.pos31.Location = new System.Drawing.Point(133, 238);
            this.pos31.Name = "pos31";
            this.pos31.Size = new System.Drawing.Size(47, 50);
            this.pos31.TabIndex = 1;
            this.pos31.TabStop = false;
            // 
            // pos32
            // 
            this.pos32.BackColor = System.Drawing.Color.Transparent;
            this.pos32.Location = new System.Drawing.Point(186, 238);
            this.pos32.Name = "pos32";
            this.pos32.Size = new System.Drawing.Size(47, 50);
            this.pos32.TabIndex = 1;
            this.pos32.TabStop = false;
            // 
            // pos33
            // 
            this.pos33.BackColor = System.Drawing.Color.Transparent;
            this.pos33.Location = new System.Drawing.Point(239, 238);
            this.pos33.Name = "pos33";
            this.pos33.Size = new System.Drawing.Size(47, 50);
            this.pos33.TabIndex = 1;
            this.pos33.TabStop = false;
            // 
            // pos20
            // 
            this.pos20.BackColor = System.Drawing.Color.Transparent;
            this.pos20.Location = new System.Drawing.Point(80, 309);
            this.pos20.Name = "pos20";
            this.pos20.Size = new System.Drawing.Size(47, 50);
            this.pos20.TabIndex = 1;
            this.pos20.TabStop = false;
            // 
            // pos21
            // 
            this.pos21.BackColor = System.Drawing.Color.Transparent;
            this.pos21.Location = new System.Drawing.Point(133, 309);
            this.pos21.Name = "pos21";
            this.pos21.Size = new System.Drawing.Size(47, 50);
            this.pos21.TabIndex = 1;
            this.pos21.TabStop = false;
            // 
            // pos22
            // 
            this.pos22.BackColor = System.Drawing.Color.Transparent;
            this.pos22.Location = new System.Drawing.Point(186, 309);
            this.pos22.Name = "pos22";
            this.pos22.Size = new System.Drawing.Size(47, 50);
            this.pos22.TabIndex = 1;
            this.pos22.TabStop = false;
            // 
            // pos23
            // 
            this.pos23.BackColor = System.Drawing.Color.Transparent;
            this.pos23.Location = new System.Drawing.Point(239, 309);
            this.pos23.Name = "pos23";
            this.pos23.Size = new System.Drawing.Size(47, 50);
            this.pos23.TabIndex = 1;
            this.pos23.TabStop = false;
            // 
            // pos10
            // 
            this.pos10.BackColor = System.Drawing.Color.Transparent;
            this.pos10.Location = new System.Drawing.Point(80, 379);
            this.pos10.Name = "pos10";
            this.pos10.Size = new System.Drawing.Size(47, 50);
            this.pos10.TabIndex = 1;
            this.pos10.TabStop = false;
            // 
            // pos11
            // 
            this.pos11.BackColor = System.Drawing.Color.Transparent;
            this.pos11.Location = new System.Drawing.Point(133, 379);
            this.pos11.Name = "pos11";
            this.pos11.Size = new System.Drawing.Size(47, 50);
            this.pos11.TabIndex = 1;
            this.pos11.TabStop = false;
            // 
            // pos12
            // 
            this.pos12.BackColor = System.Drawing.Color.Transparent;
            this.pos12.Location = new System.Drawing.Point(186, 379);
            this.pos12.Name = "pos12";
            this.pos12.Size = new System.Drawing.Size(47, 50);
            this.pos12.TabIndex = 1;
            this.pos12.TabStop = false;
            // 
            // pos13
            // 
            this.pos13.BackColor = System.Drawing.Color.Transparent;
            this.pos13.Location = new System.Drawing.Point(239, 379);
            this.pos13.Name = "pos13";
            this.pos13.Size = new System.Drawing.Size(47, 50);
            this.pos13.TabIndex = 1;
            this.pos13.TabStop = false;
            // 
            // posOperario
            // 
            this.posOperario.BackColor = System.Drawing.Color.Transparent;
            this.posOperario.Location = new System.Drawing.Point(155, 448);
            this.posOperario.Name = "posOperario";
            this.posOperario.Size = new System.Drawing.Size(47, 50);
            this.posOperario.TabIndex = 1;
            this.posOperario.TabStop = false;
            // 
            // posRei
            // 
            this.posRei.BackColor = System.Drawing.Color.Transparent;
            this.posRei.Location = new System.Drawing.Point(155, 29);
            this.posRei.Name = "posRei";
            this.posRei.Size = new System.Drawing.Size(47, 50);
            this.posRei.TabIndex = 1;
            this.posRei.TabStop = false;
            // 
            // A
            // 
            this.A.BackColor = System.Drawing.Color.DarkRed;
            this.A.Image = ((System.Drawing.Image)(resources.GetObject("A.Image")));
            this.A.Location = new System.Drawing.Point(371, 16);
            this.A.Name = "A";
            this.A.Size = new System.Drawing.Size(47, 50);
            this.A.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.A.TabIndex = 1;
            this.A.TabStop = false;
            // 
            // B
            // 
            this.B.BackColor = System.Drawing.Color.DarkRed;
            this.B.Image = ((System.Drawing.Image)(resources.GetObject("B.Image")));
            this.B.Location = new System.Drawing.Point(424, 16);
            this.B.Name = "B";
            this.B.Size = new System.Drawing.Size(47, 50);
            this.B.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.B.TabIndex = 1;
            this.B.TabStop = false;
            // 
            // C
            // 
            this.C.BackColor = System.Drawing.Color.DarkRed;
            this.C.Image = ((System.Drawing.Image)(resources.GetObject("C.Image")));
            this.C.Location = new System.Drawing.Point(477, 16);
            this.C.Name = "C";
            this.C.Size = new System.Drawing.Size(47, 50);
            this.C.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.C.TabIndex = 1;
            this.C.TabStop = false;
            // 
            // D
            // 
            this.D.BackColor = System.Drawing.Color.DarkRed;
            this.D.Image = ((System.Drawing.Image)(resources.GetObject("D.Image")));
            this.D.Location = new System.Drawing.Point(530, 16);
            this.D.Name = "D";
            this.D.Size = new System.Drawing.Size(47, 50);
            this.D.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.D.TabIndex = 1;
            this.D.TabStop = false;
            // 
            // E
            // 
            this.E.BackColor = System.Drawing.Color.DarkRed;
            this.E.Image = ((System.Drawing.Image)(resources.GetObject("E.Image")));
            this.E.Location = new System.Drawing.Point(371, 72);
            this.E.Name = "E";
            this.E.Size = new System.Drawing.Size(47, 50);
            this.E.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.E.TabIndex = 1;
            this.E.TabStop = false;
            // 
            // G
            // 
            this.G.BackColor = System.Drawing.Color.DarkRed;
            this.G.Image = ((System.Drawing.Image)(resources.GetObject("G.Image")));
            this.G.Location = new System.Drawing.Point(477, 72);
            this.G.Name = "G";
            this.G.Size = new System.Drawing.Size(47, 50);
            this.G.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.G.TabIndex = 1;
            this.G.TabStop = false;
            // 
            // F
            // 
            this.F.BackColor = System.Drawing.Color.DarkRed;
            this.F.Image = ((System.Drawing.Image)(resources.GetObject("F.Image")));
            this.F.Location = new System.Drawing.Point(424, 72);
            this.F.Name = "F";
            this.F.Size = new System.Drawing.Size(47, 50);
            this.F.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.F.TabIndex = 1;
            this.F.TabStop = false;
            // 
            // H
            // 
            this.H.BackColor = System.Drawing.Color.DarkRed;
            this.H.Image = ((System.Drawing.Image)(resources.GetObject("H.Image")));
            this.H.Location = new System.Drawing.Point(530, 72);
            this.H.Name = "H";
            this.H.Size = new System.Drawing.Size(47, 50);
            this.H.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.H.TabIndex = 1;
            this.H.TabStop = false;
            // 
            // I
            // 
            this.I.BackColor = System.Drawing.Color.DarkRed;
            this.I.Image = ((System.Drawing.Image)(resources.GetObject("I.Image")));
            this.I.Location = new System.Drawing.Point(371, 128);
            this.I.Name = "I";
            this.I.Size = new System.Drawing.Size(47, 50);
            this.I.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.I.TabIndex = 1;
            this.I.TabStop = false;
            // 
            // K
            // 
            this.K.BackColor = System.Drawing.Color.DarkRed;
            this.K.Image = ((System.Drawing.Image)(resources.GetObject("K.Image")));
            this.K.Location = new System.Drawing.Point(477, 128);
            this.K.Name = "K";
            this.K.Size = new System.Drawing.Size(47, 50);
            this.K.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.K.TabIndex = 1;
            this.K.TabStop = false;
            // 
            // J
            // 
            this.J.BackColor = System.Drawing.Color.DarkRed;
            this.J.Image = ((System.Drawing.Image)(resources.GetObject("J.Image")));
            this.J.Location = new System.Drawing.Point(424, 128);
            this.J.Name = "J";
            this.J.Size = new System.Drawing.Size(47, 50);
            this.J.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.J.TabIndex = 1;
            this.J.TabStop = false;
            // 
            // L
            // 
            this.L.BackColor = System.Drawing.Color.DarkRed;
            this.L.Image = ((System.Drawing.Image)(resources.GetObject("L.Image")));
            this.L.Location = new System.Drawing.Point(530, 128);
            this.L.Name = "L";
            this.L.Size = new System.Drawing.Size(47, 50);
            this.L.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.L.TabIndex = 1;
            this.L.TabStop = false;
            // 
            // M
            // 
            this.M.BackColor = System.Drawing.Color.DarkRed;
            this.M.Image = ((System.Drawing.Image)(resources.GetObject("M.Image")));
            this.M.Location = new System.Drawing.Point(371, 184);
            this.M.Name = "M";
            this.M.Size = new System.Drawing.Size(47, 50);
            this.M.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.M.TabIndex = 1;
            this.M.TabStop = false;
            // 
            // mensagem
            // 
            this.mensagem.AutoSize = true;
            this.mensagem.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mensagem.ForeColor = System.Drawing.Color.Red;
            this.mensagem.Location = new System.Drawing.Point(368, 270);
            this.mensagem.Name = "mensagem";
            this.mensagem.Size = new System.Drawing.Size(138, 18);
            this.mensagem.TabIndex = 2;
            this.mensagem.Text = "Aguarde sua Vez!";
            this.mensagem.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(368, 359);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(138, 15);
            this.label2.TabIndex = 4;
            this.label2.Text = "Escolha o Personagem";
            // 
            // cmbPersonagens
            // 
            this.cmbPersonagens.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPersonagens.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.cmbPersonagens.FormattingEnabled = true;
            this.cmbPersonagens.Location = new System.Drawing.Point(371, 377);
            this.cmbPersonagens.MaxDropDownItems = 20;
            this.cmbPersonagens.Name = "cmbPersonagens";
            this.cmbPersonagens.Size = new System.Drawing.Size(206, 21);
            this.cmbPersonagens.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(368, 410);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(107, 15);
            this.label3.TabIndex = 4;
            this.label3.Text = "Escolha o destino";
            // 
            // cmbDestino
            // 
            this.cmbDestino.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbDestino.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.cmbDestino.FormattingEnabled = true;
            this.cmbDestino.Location = new System.Drawing.Point(371, 428);
            this.cmbDestino.MaxDropDownItems = 20;
            this.cmbDestino.Name = "cmbDestino";
            this.cmbDestino.Size = new System.Drawing.Size(206, 21);
            this.cmbDestino.TabIndex = 5;
            // 
            // btnVerificarVez
            // 
            this.btnVerificarVez.BackColor = System.Drawing.Color.DarkCyan;
            this.btnVerificarVez.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVerificarVez.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVerificarVez.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnVerificarVez.Location = new System.Drawing.Point(371, 309);
            this.btnVerificarVez.Name = "btnVerificarVez";
            this.btnVerificarVez.Size = new System.Drawing.Size(206, 32);
            this.btnVerificarVez.TabIndex = 22;
            this.btnVerificarVez.Text = "VERIFICAR VEZ";
            this.btnVerificarVez.UseVisualStyleBackColor = false;
            this.btnVerificarVez.Click += new System.EventHandler(this.btnVerificarVez_Click);
            // 
            // btnConfirmarJogada
            // 
            this.btnConfirmarJogada.BackColor = System.Drawing.Color.DarkCyan;
            this.btnConfirmarJogada.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnConfirmarJogada.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConfirmarJogada.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnConfirmarJogada.Location = new System.Drawing.Point(371, 466);
            this.btnConfirmarJogada.Name = "btnConfirmarJogada";
            this.btnConfirmarJogada.Size = new System.Drawing.Size(206, 32);
            this.btnConfirmarJogada.TabIndex = 22;
            this.btnConfirmarJogada.Text = "CONFIRMAR JOGADA";
            this.btnConfirmarJogada.UseVisualStyleBackColor = false;
            this.btnConfirmarJogada.Click += new System.EventHandler(this.btnConfirmarJogada_Click);
            // 
            // Tabuleiro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(594, 526);
            this.Controls.Add(this.btnConfirmarJogada);
            this.Controls.Add(this.btnVerificarVez);
            this.Controls.Add(this.cmbDestino);
            this.Controls.Add(this.cmbPersonagens);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.mensagem);
            this.Controls.Add(this.pos13);
            this.Controls.Add(this.pos23);
            this.Controls.Add(this.pos33);
            this.Controls.Add(this.pos43);
            this.Controls.Add(this.pos53);
            this.Controls.Add(this.L);
            this.Controls.Add(this.H);
            this.Controls.Add(this.D);
            this.Controls.Add(this.J);
            this.Controls.Add(this.F);
            this.Controls.Add(this.B);
            this.Controls.Add(this.K);
            this.Controls.Add(this.G);
            this.Controls.Add(this.C);
            this.Controls.Add(this.M);
            this.Controls.Add(this.I);
            this.Controls.Add(this.E);
            this.Controls.Add(this.A);
            this.Controls.Add(this.posRei);
            this.Controls.Add(this.posOperario);
            this.Controls.Add(this.pos12);
            this.Controls.Add(this.pos22);
            this.Controls.Add(this.pos32);
            this.Controls.Add(this.pos42);
            this.Controls.Add(this.pos52);
            this.Controls.Add(this.pos11);
            this.Controls.Add(this.pos10);
            this.Controls.Add(this.pos21);
            this.Controls.Add(this.pos20);
            this.Controls.Add(this.pos31);
            this.Controls.Add(this.pos30);
            this.Controls.Add(this.pos41);
            this.Controls.Add(this.pos40);
            this.Controls.Add(this.pos51);
            this.Controls.Add(this.pos50);
            this.Name = "Tabuleiro";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tabuleiro";
            this.Load += new System.EventHandler(this.Tabuleiro_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pos50)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pos51)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pos52)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pos53)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pos40)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pos41)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pos42)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pos43)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pos30)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pos31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pos32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pos33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pos20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pos21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pos22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pos23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pos10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pos11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pos12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pos13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.posOperario)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.posRei)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.A)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.B)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.D)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.E)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.G)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.F)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.H)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.I)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.K)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.J)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.L)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.M)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pos50;
        private System.Windows.Forms.PictureBox pos51;
        private System.Windows.Forms.PictureBox pos52;
        private System.Windows.Forms.PictureBox pos53;
        private System.Windows.Forms.PictureBox pos40;
        private System.Windows.Forms.PictureBox pos41;
        private System.Windows.Forms.PictureBox pos42;
        private System.Windows.Forms.PictureBox pos43;
        private System.Windows.Forms.PictureBox pos30;
        private System.Windows.Forms.PictureBox pos31;
        private System.Windows.Forms.PictureBox pos32;
        private System.Windows.Forms.PictureBox pos33;
        private System.Windows.Forms.PictureBox pos20;
        private System.Windows.Forms.PictureBox pos21;
        private System.Windows.Forms.PictureBox pos22;
        private System.Windows.Forms.PictureBox pos23;
        private System.Windows.Forms.PictureBox pos10;
        private System.Windows.Forms.PictureBox pos11;
        private System.Windows.Forms.PictureBox pos12;
        private System.Windows.Forms.PictureBox pos13;
        private System.Windows.Forms.PictureBox posOperario;
        private System.Windows.Forms.PictureBox posRei;
        private System.Windows.Forms.PictureBox A;
        private System.Windows.Forms.PictureBox B;
        private System.Windows.Forms.PictureBox C;
        private System.Windows.Forms.PictureBox D;
        private System.Windows.Forms.PictureBox E;
        private System.Windows.Forms.PictureBox G;
        private System.Windows.Forms.PictureBox F;
        private System.Windows.Forms.PictureBox H;
        private System.Windows.Forms.PictureBox I;
        private System.Windows.Forms.PictureBox K;
        private System.Windows.Forms.PictureBox J;
        private System.Windows.Forms.PictureBox L;
        private System.Windows.Forms.PictureBox M;
        private System.Windows.Forms.Label mensagem;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbPersonagens;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cmbDestino;
        private System.Windows.Forms.Button btnVerificarVez;
        private System.Windows.Forms.Button btnConfirmarJogada;
    }
}